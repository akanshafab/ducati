<?php get_header(); ?>
	<div class="page-wrapper">
		<div class="page-internal-wrapper">
			<div class="d-editor-text -wide _module-space-bottom">
    			<div class="body">
    				<div class="content">
		                <h1>Page not found</h1>
		                <?php get_search_form();?>
        			</div>
    			</div>
			</div>
		</div>
	</div>
<?php 
get_footer();
?>
